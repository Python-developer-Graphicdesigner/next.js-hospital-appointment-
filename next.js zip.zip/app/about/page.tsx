'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function AboutPage() {
  const stats = [
    { number: '15+', label: 'Years of Excellence' },
    { number: '50+', label: 'Expert Doctors' },
    { number: '10,000+', label: 'Happy Patients' },
    { number: '24/7', label: 'Emergency Care' }
  ];

  const team = [
    {
      name: 'Dr. Jennifer Adams',
      position: 'Chief Medical Officer',
      image: 'https://readdy.ai/api/search-image?query=Professional%20female%20chief%20medical%20officer%20in%20business%20attire%20with%20confident%20expression%20in%20modern%20hospital%20office%2C%20executive%20healthcare%20leadership%20portrait%20with%20clean%20background&width=400&height=400&seq=team1&orientation=squarish',
      description: 'Leading our medical team with over 20 years of healthcare management experience.'
    },
    {
      name: 'Mark Johnson',
      position: 'Hospital Administrator',
      image: 'https://readdy.ai/api/search-image?query=Professional%20male%20hospital%20administrator%20in%20business%20suit%20with%20friendly%20expression%20in%20modern%20medical%20facility%20office%2C%20healthcare%20management%20portrait%20with%20clean%20background&width=400&height=400&seq=team2&orientation=squarish',
      description: 'Ensuring smooth operations and exceptional patient care experiences.'
    },
    {
      name: 'Sarah Mitchell',
      position: 'Director of Nursing',
      image: 'https://readdy.ai/api/search-image?query=Professional%20female%20nursing%20director%20in%20medical%20scrubs%20with%20warm%20smile%20in%20hospital%20setting%2C%20healthcare%20leadership%20portrait%20with%20clean%20medical%20background&width=400&height=400&seq=team3&orientation=squarish',
      description: 'Overseeing our dedicated nursing staff and patient care standards.'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section className="relative bg-sky-50 py-20"
               style={{
                 backgroundImage: `url('https://readdy.ai/api/search-image?query=Modern%20hospital%20building%20exterior%20with%20glass%20facade%20and%20clean%20architecture%2C%20professional%20healthcare%20facility%20with%20blue%20sky%20and%20landscaping%2C%20medical%20center%20campus%20view&width=1200&height=600&seq=about1&orientation=landscape')`,
                 backgroundSize: 'cover',
                 backgroundPosition: 'center'
               }}>
        <div className="absolute inset-0 bg-white/85"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl font-bold text-gray-800 mb-6">About MediCare Hospital</h1>
            <p className="text-xl text-gray-600 leading-relaxed">
              For over 15 years, we have been committed to providing exceptional healthcare services 
              with compassion, innovation, and excellence. Our mission is to improve the health and 
              wellbeing of our community through world-class medical care.
            </p>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-sky-600 mb-2">{stat.number}</div>
                <div className="text-gray-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 bg-sky-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="w-16 h-16 bg-sky-500 rounded-full flex items-center justify-center mb-6">
                <i className="ri-heart-line text-white text-2xl"></i>
              </div>
              <h2 className="text-3xl font-bold text-gray-800 mb-4">Our Mission</h2>
              <p className="text-gray-600 leading-relaxed mb-6">
                To provide comprehensive, compassionate, and accessible healthcare services that improve 
                the quality of life for our patients and community. We are committed to excellence in 
                medical care, education, and research.
              </p>
              <ul className="space-y-3">
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-sky-500 rounded-full mr-3"></div>
                  <span className="text-gray-600">Patient-centered care approach</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-sky-500 rounded-full mr-3"></div>
                  <span className="text-gray-600">Continuous medical innovation</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-sky-500 rounded-full mr-3"></div>
                  <span className="text-gray-600">Community health improvement</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="w-16 h-16 bg-sky-500 rounded-full flex items-center justify-center mb-6">
                <i className="ri-eye-line text-white text-2xl"></i>
              </div>
              <h2 className="text-3xl font-bold text-gray-800 mb-4">Our Vision</h2>
              <p className="text-gray-600 leading-relaxed mb-6">
                To be the leading healthcare provider in our region, recognized for our clinical excellence, 
                innovative treatments, and exceptional patient experiences. We envision a healthier community 
                where everyone has access to quality medical care.
              </p>
              <ul className="space-y-3">
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-sky-500 rounded-full mr-3"></div>
                  <span className="text-gray-600">Regional healthcare leadership</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-sky-500 rounded-full mr-3"></div>
                  <span className="text-gray-600">Advanced medical technology</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-sky-500 rounded-full mr-3"></div>
                  <span className="text-gray-600">Accessible healthcare for all</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Leadership Team */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Our Leadership Team</h2>
            <p className="text-xl text-gray-600">
              Experienced leaders dedicated to excellence in healthcare
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <div key={index} className="bg-sky-50 rounded-2xl overflow-hidden shadow-lg">
                <div className="aspect-square overflow-hidden">
                  <img 
                    src={member.image} 
                    alt={member.name}
                    className="w-full h-full object-cover object-top"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-gray-800 mb-1">{member.name}</h3>
                  <p className="text-sky-600 font-medium mb-3">{member.position}</p>
                  <p className="text-gray-600 text-sm leading-relaxed">{member.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-sky-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Our Core Values</h2>
            <p className="text-xl text-gray-600">
              The principles that guide everything we do
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: 'ri-heart-3-line', title: 'Compassion', desc: 'Treating every patient with empathy and understanding' },
              { icon: 'ri-shield-check-line', title: 'Excellence', desc: 'Striving for the highest standards in everything we do' },
              { icon: 'ri-team-line', title: 'Collaboration', desc: 'Working together to achieve the best outcomes' },
              { icon: 'ri-lightbulb-line', title: 'Innovation', desc: 'Embracing new technologies and treatment methods' }
            ].map((value, index) => (
              <div key={index} className="bg-white rounded-2xl p-8 text-center shadow-lg">
                <div className="w-16 h-16 bg-sky-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className={`${value.icon} text-white text-2xl`}></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-3">{value.title}</h3>
                <p className="text-gray-600 leading-relaxed">{value.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="bg-sky-500 rounded-2xl p-12 text-center text-white">
            <h2 className="text-4xl font-bold mb-4">Ready to Experience Quality Healthcare?</h2>
            <p className="text-xl mb-8 opacity-90">
              Join thousands of satisfied patients who trust us with their health
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/appointment" className="bg-white text-sky-600 px-8 py-4 rounded-full text-lg font-semibold hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap">
                Book Appointment
              </Link>
              <Link href="/contact" className="border-2 border-white text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-white hover:text-sky-600 transition-colors cursor-pointer whitespace-nowrap">
                Contact Us
              </Link>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}