'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useState } from 'react';

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState('appointments');
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [cancellingId, setCancellingId] = useState(null);

  const upcomingAppointments = [
    {
      id: 1,
      doctor: 'Dr. Sarah Johnson',
      specialty: 'Cardiologist',
      date: '2024-01-25',
      time: '10:00 AM',
      reason: 'Regular checkup',
      status: 'confirmed',
      image: 'https://readdy.ai/api/search-image?query=Professional%20female%20cardiologist%20doctor%20in%20white%20coat%20smiling%20warmly%20in%20modern%20hospital%20setting%20with%20soft%20lighting%20and%20clean%20medical%20background%2C%20confident%20and%20approachable%20healthcare%20professional%20portrait&width=400&height=400&seq=doc1&orientation=squarish'
    },
    {
      id: 2,
      doctor: 'Dr. Michael Chen',
      specialty: 'Neurologist',
      date: '2024-01-28',
      time: '2:00 PM',
      reason: 'Follow-up consultation',
      status: 'confirmed',
      image: 'https://readdy.ai/api/search-image?query=Professional%20male%20neurologist%20doctor%20in%20white%20medical%20coat%20with%20stethoscope%20in%20modern%20hospital%20environment%2C%20clean%20background%20with%20soft%20medical%20lighting%2C%20trustworthy%20healthcare%20specialist%20portrait&width=400&height=400&seq=doc2&orientation=squarish'
    }
  ];

  const completedAppointments = [
    {
      id: 3,
      doctor: 'Dr. Emily Rodriguez',
      specialty: 'Pediatrician',
      date: '2024-01-15',
      time: '11:00 AM',
      reason: 'Annual physical',
      status: 'completed',
      image: 'https://readdy.ai/api/search-image?query=Friendly%20female%20pediatrician%20doctor%20in%20white%20coat%20smiling%20with%20child-friendly%20demeanor%20in%20bright%20modern%20medical%20office%2C%20soft%20lighting%20and%20clean%20healthcare%20background%2C%20caring%20healthcare%20professional&width=400&height=400&seq=doc3&orientation=squarish'
    },
    {
      id: 4,
      doctor: 'Dr. Robert Thompson',
      specialty: 'Orthopedic Surgeon',
      date: '2024-01-10',
      time: '3:00 PM',
      reason: 'Knee evaluation',
      status: 'completed',
      image: 'https://readdy.ai/api/search-image?query=Professional%20male%20orthopedic%20surgeon%20in%20white%20medical%20coat%20with%20confident%20expression%20in%20modern%20hospital%20setting%2C%20clean%20medical%20background%20with%20soft%20professional%20lighting%2C%20experienced%20healthcare%20specialist&width=400&height=400&seq=doc4&orientation=squarish'
    }
  ];

  const cancelledAppointments = [
    {
      id: 5,
      doctor: 'Dr. Sarah Johnson',
      specialty: 'Cardiologist',
      date: '2024-01-12',
      time: '9:00 AM',
      reason: 'Consultation',
      status: 'cancelled',
      image: 'https://readdy.ai/api/search-image?query=Professional%20female%20cardiologist%20doctor%20in%20white%20coat%20smiling%20warmly%20in%20modern%20hospital%20setting%20with%20soft%20lighting%20and%20clean%20medical%20background%2C%20confident%20and%20approachable%20healthcare%20professional%20portrait&width=400&height=400&seq=doc1&orientation=squarish'
    }
  ];

  const handleCancelAppointment = (id: any) => {
    setCancellingId(id);
    setShowCancelModal(true);
  };

  const confirmCancel = () => {
    console.log('Cancelling appointment:', cancellingId);
    setShowCancelModal(false);
    setCancellingId(null);
  };

  const renderAppointmentCard = (appointment: any, showActions = false) => (
    <div key={appointment.id} className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-start space-x-4">
        <img 
          src={appointment.image} 
          alt={appointment.doctor}
          className="w-16 h-16 rounded-full object-cover object-top"
        />
        <div className="flex-1">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="text-lg font-semibold text-gray-800">{appointment.doctor}</h3>
              <p className="text-sky-600 font-medium">{appointment.specialty}</p>
              <p className="text-gray-600 text-sm mt-1">{appointment.reason}</p>
            </div>
            <div className="text-right">
              <div className="flex items-center space-x-2 mb-2">
                <div className="w-4 h-4 flex items-center justify-center">
                  <i className="ri-calendar-line text-gray-500"></i>
                </div>
                <span className="text-sm text-gray-600">{appointment.date}</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 flex items-center justify-center">
                  <i className="ri-time-line text-gray-500"></i>
                </div>
                <span className="text-sm text-gray-600">{appointment.time}</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center justify-between mt-4">
            <span className={`px-3 py-1 rounded-full text-xs font-medium ${
              appointment.status === 'confirmed' ? 'bg-green-100 text-green-800' :
              appointment.status === 'completed' ? 'bg-blue-100 text-blue-800' :
              'bg-red-100 text-red-800'
            }`}>
              {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
            </span>
            
            {showActions && appointment.status === 'confirmed' && (
              <div className="flex space-x-2">
                <button className="text-sky-600 hover:text-sky-700 text-sm font-medium cursor-pointer whitespace-nowrap">
                  Reschedule
                </button>
                <button 
                  onClick={() => handleCancelAppointment(appointment.id)}
                  className="text-red-600 hover:text-red-700 text-sm font-medium cursor-pointer whitespace-nowrap"
                >
                  Cancel
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <div className="bg-sky-50 py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-800 mb-4">Patient Dashboard</h1>
            <p className="text-xl text-gray-600">Manage your appointments and health records</p>
          </div>

          <div className="max-w-6xl mx-auto">
            {/* Welcome Card */}
            <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-sky-500 rounded-full flex items-center justify-center">
                  <i className="ri-user-line text-white text-2xl"></i>
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-gray-800">Welcome back, John Smith</h2>
                  <p className="text-gray-600">Patient ID: PT-2024-001</p>
                  <p className="text-sm text-gray-500">Last login: January 20, 2024</p>
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <div className="bg-white rounded-xl p-6 shadow-lg text-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className="ri-calendar-check-line text-green-600 text-xl"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-800">{upcomingAppointments.length}</h3>
                <p className="text-gray-600">Upcoming</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-lg text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className="ri-checkbox-circle-line text-blue-600 text-xl"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-800">{completedAppointments.length}</h3>
                <p className="text-gray-600">Completed</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-lg text-center">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className="ri-close-circle-line text-red-600 text-xl"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-800">{cancelledAppointments.length}</h3>
                <p className="text-gray-600">Cancelled</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-lg text-center">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className="ri-file-text-line text-purple-600 text-xl"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-800">8</h3>
                <p className="text-gray-600">Reports</p>
              </div>
            </div>

            {/* Navigation Tabs */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="border-b border-gray-200">
                <nav className="flex">
                  {[
                    { id: 'appointments', label: 'My Appointments', icon: 'ri-calendar-line' },
                    { id: 'profile', label: 'Profile', icon: 'ri-user-line' },
                    { id: 'reports', label: 'Medical Reports', icon: 'ri-file-text-line' },
                    { id: 'billing', label: 'Billing', icon: 'ri-bill-line' }
                  ].map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`flex items-center space-x-2 px-6 py-4 font-medium border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                        activeTab === tab.id 
                          ? 'border-sky-500 text-sky-600 bg-sky-50' 
                          : 'border-transparent text-gray-600 hover:text-gray-800'
                      }`}
                    >
                      <div className="w-5 h-5 flex items-center justify-center">
                        <i className={`${tab.icon} text-lg`}></i>
                      </div>
                      <span>{tab.label}</span>
                    </button>
                  ))}
                </nav>
              </div>

              <div className="p-8">
                {/* Appointments Tab */}
                {activeTab === 'appointments' && (
                  <div className="space-y-8">
                    <div>
                      <h3 className="text-xl font-semibold text-gray-800 mb-4">Upcoming Appointments</h3>
                      {upcomingAppointments.length > 0 ? (
                        <div className="space-y-4">
                          {upcomingAppointments.map(appointment => renderAppointmentCard(appointment, true))}
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i className="ri-calendar-line text-gray-400 text-2xl"></i>
                          </div>
                          <p className="text-gray-600">No upcoming appointments</p>
                        </div>
                      )}
                    </div>

                    <div>
                      <h3 className="text-xl font-semibold text-gray-800 mb-4">Recent Appointments</h3>
                      <div className="space-y-4">
                        {completedAppointments.map(appointment => renderAppointmentCard(appointment))}
                        {cancelledAppointments.map(appointment => renderAppointmentCard(appointment))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Profile Tab */}
                {activeTab === 'profile' && (
                  <div className="max-w-2xl">
                    <h3 className="text-xl font-semibold text-gray-800 mb-6">Personal Information</h3>
                    <form className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <label className="block text-gray-700 font-medium mb-2">First Name</label>
                          <input 
                            type="text" 
                            value="John"
                            className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                          />
                        </div>
                        <div>
                          <label className="block text-gray-700 font-medium mb-2">Last Name</label>
                          <input 
                            type="text" 
                            value="Smith"
                            className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-gray-700 font-medium mb-2">Email Address</label>
                        <input 
                          type="email" 
                          value="john.smith@email.com"
                          className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                        />
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <label className="block text-gray-700 font-medium mb-2">Phone Number</label>
                          <input 
                            type="tel" 
                            value="+1 (555) 123-4567"
                            className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                          />
                        </div>
                        <div>
                          <label className="block text-gray-700 font-medium mb-2">Date of Birth</label>
                          <input 
                            type="date" 
                            value="1985-06-15"
                            className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                          />
                        </div>
                      </div>
                      <button 
                        type="submit"
                        className="bg-sky-500 text-white px-8 py-3 rounded-lg font-semibold hover:bg-sky-600 transition-colors cursor-pointer whitespace-nowrap"
                      >
                        Update Profile
                      </button>
                    </form>
                  </div>
                )}

                {/* Reports Tab */}
                {activeTab === 'reports' && (
                  <div>
                    <h3 className="text-xl font-semibold text-gray-800 mb-6">Medical Reports</h3>
                    <div className="space-y-4">
                      {[
                        { name: 'Blood Test Results', date: '2024-01-15', doctor: 'Dr. Sarah Johnson', type: 'Lab Report' },
                        { name: 'X-Ray Report', date: '2024-01-10', doctor: 'Dr. Robert Thompson', type: 'Imaging' },
                        { name: 'Annual Physical', date: '2024-01-05', doctor: 'Dr. Emily Rodriguez', type: 'Checkup' }
                      ].map((report, index) => (
                        <div key={index} className="bg-gray-50 rounded-lg p-6 flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                            <div className="w-12 h-12 bg-sky-100 rounded-full flex items-center justify-center">
                              <i className="ri-file-text-line text-sky-600 text-xl"></i>
                            </div>
                            <div>
                              <h4 className="font-semibold text-gray-800">{report.name}</h4>
                              <p className="text-sm text-gray-600">{report.doctor} • {report.date}</p>
                              <span className="text-xs text-sky-600 bg-sky-100 px-2 py-1 rounded-full">{report.type}</span>
                            </div>
                          </div>
                          <button className="text-sky-600 hover:text-sky-700 font-medium cursor-pointer whitespace-nowrap">
                            Download
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Billing Tab */}
                {activeTab === 'billing' && (
                  <div>
                    <h3 className="text-xl font-semibold text-gray-800 mb-6">Billing History</h3>
                    <div className="space-y-4">
                      {[
                        { id: 'INV-001', date: '2024-01-15', amount: '$150.00', status: 'Paid', service: 'Consultation - Dr. Sarah Johnson' },
                        { id: 'INV-002', date: '2024-01-10', amount: '$200.00', status: 'Paid', service: 'X-Ray Examination - Dr. Robert Thompson' },
                        { id: 'INV-003', date: '2024-01-05', amount: '$120.00', status: 'Pending', service: 'Lab Tests - Dr. Emily Rodriguez' }
                      ].map((bill) => (
                        <div key={bill.id} className="bg-gray-50 rounded-lg p-6">
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="font-semibold text-gray-800">{bill.service}</h4>
                              <p className="text-sm text-gray-600">Invoice #{bill.id} • {bill.date}</p>
                            </div>
                            <div className="text-right">
                              <p className="text-lg font-semibold text-gray-800">{bill.amount}</p>
                              <span className={`text-xs px-2 py-1 rounded-full ${
                                bill.status === 'Paid' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                              }`}>
                                {bill.status}
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Cancel Confirmation Modal */}
      {showCancelModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 max-w-md mx-4">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mr-4">
                <i className="ri-error-warning-line text-red-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-800">Cancel Appointment</h3>
            </div>
            <p className="text-gray-600 mb-6">
              Are you sure you want to cancel this appointment? This action cannot be undone.
            </p>
            <div className="flex space-x-4">
              <button 
                onClick={() => setShowCancelModal(false)}
                className="flex-1 bg-gray-500 text-white py-3 rounded-lg font-semibold hover:bg-gray-600 transition-colors cursor-pointer whitespace-nowrap"
              >
                Keep Appointment
              </button>
              <button 
                onClick={confirmCancel}
                className="flex-1 bg-red-500 text-white py-3 rounded-lg font-semibold hover:bg-red-600 transition-colors cursor-pointer whitespace-nowrap"
              >
                Cancel Appointment
              </button>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}