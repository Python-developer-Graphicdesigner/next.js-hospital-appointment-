
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';
import { useState, useEffect } from 'react';

export default function Home() {
  const [selectedDoctor, setSelectedDoctor] = useState('');
  const [appointmentDate, setAppointmentDate] = useState('');
  const [appointmentTime, setAppointmentTime] = useState('');
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [currentStat, setCurrentStat] = useState(0);
  const [isMounted, setIsMounted] = useState(false);

  const doctors = [
    {
      id: 1,
      name: 'Dr. Sarah Johnson',
      specialty: 'Cardiologist',
      experience: '15 years',
      rating: 4.9,
      image: 'https://readdy.ai/api/search-image?query=Professional%20female%20cardiologist%20doctor%20in%20white%20coat%20smiling%20warmly%20in%20modern%20hospital%20setting%20with%20soft%20lighting%20and%20clean%20medical%20background%2C%20confident%20and%20approachable%20healthcare%20professional%20portrait&width=400&height=400&seq=doc1&orientation=squarish',
      availability: ['9:00 AM', '11:00 AM', '2:00 PM', '4:00 PM']
    },
    {
      id: 2,
      name: 'Dr. Michael Chen',
      specialty: 'Neurologist',
      experience: '12 years',
      rating: 4.8,
      image: 'https://readdy.ai/api/search-image?query=Professional%20male%20neurologist%20doctor%20in%20white%20medical%20coat%20with%20stethoscope%20in%20modern%20hospital%20environment%2C%20clean%20background%20with%20soft%20medical%20lighting%2C%20trustworthy%20healthcare%20specialist%20portrait&width=400&height=400&seq=doc2&orientation=squarish',
      availability: ['10:00 AM', '1:00 PM', '3:00 PM', '5:00 PM']
    },
    {
      id: 3,
      name: 'Dr. Emily Rodriguez',
      specialty: 'Pediatrician',
      experience: '10 years',
      rating: 4.9,
      image: 'https://readdy.ai/api/search-image?query=Friendly%20female%20pediatrician%20doctor%20in%20white%20coat%20smiling%20with%20child-friendly%20demeanor%20in%20bright%20modern%20medical%20office%2C%20soft%20lighting%20and%20clean%20healthcare%20background%2C%20caring%20healthcare%20professional&width=400&height=400&seq=doc3&orientation=squarish',
      availability: ['8:00 AM', '10:00 AM', '1:00 PM', '3:00 PM']
    },
    {
      id: 4,
      name: 'Dr. Robert Thompson',
      specialty: 'Orthopedic Surgeon',
      experience: '18 years',
      rating: 4.7,
      image: 'https://readdy.ai/api/search-image?query=Professional%20male%20orthopedic%20surgeon%20in%20white%20medical%20coat%20with%20confident%20expression%20in%20modern%20hospital%20setting%2C%20clean%20medical%20background%20with%20soft%20professional%20lighting%2C%20experienced%20healthcare%20specialist&width=400&height=400&seq=doc4&orientation=squarish',
      availability: ['9:00 AM', '12:00 PM', '2:00 PM', '4:00 PM']
    }
  ];

  const testimonials = [
    {
      name: 'Jennifer Martinez',
      text: 'Outstanding care and professionalism. The online booking system made scheduling so convenient.',
      rating: 5,
      role: 'Business Executive',
      image: 'https://readdy.ai/api/search-image?query=Happy%20satisfied%20female%20patient%20smiling%20warmly%20with%20bright%20clean%20background%2C%20professional%20healthcare%20testimonial%20portrait%20with%20soft%20lighting%20and%20positive%20expression&width=80&height=80&seq=test1&orientation=squarish'
    },
    {
      name: 'David Park',
      text: 'Dr. Johnson provided excellent treatment for my heart condition. Highly recommend this hospital.',
      rating: 5,
      role: 'Engineer',
      image: 'https://readdy.ai/api/search-image?query=Grateful%20male%20patient%20with%20satisfied%20expression%20and%20clean%20bright%20background%2C%20professional%20healthcare%20testimonial%20portrait%20with%20positive%20demeanor%20and%20soft%20lighting&width=80&height=80&seq=test2&orientation=squarish'
    },
    {
      name: 'Lisa Chen',
      text: 'The staff is incredibly caring and the facilities are top-notch. Great experience overall.',
      rating: 5,
      role: 'Teacher',
      image: 'https://readdy.ai/api/search-image?query=Pleased%20female%20patient%20with%20warm%20smile%20and%20bright%20clean%20background%2C%20professional%20healthcare%20testimonial%20portrait%20with%20happy%20expression%20and%20soft%20lighting&width=80&height=80&seq=test3&orientation=squarish'
    },
    {
      name: 'Michael Thompson',
      text: 'Emergency care was exceptional. The team was quick, professional, and compassionate.',
      rating: 5,
      role: 'Designer',
      image: 'https://readdy.ai/api/search-image?query=Satisfied%20male%20patient%20with%20grateful%20expression%20and%20bright%20clean%20background%2C%20professional%20healthcare%20testimonial%20portrait%20with%20positive%20demeanor%20and%20soft%20lighting&width=80&height=80&seq=test4&orientation=squarish'
    }
  ];

  const stats = [
    { number: '50,000+', label: 'Patients Treated', icon: 'ri-user-heart-line' },
    { number: '200+', label: 'Expert Doctors', icon: 'ri-stethoscope-line' },
    { number: '15+', label: 'Specialties', icon: 'ri-hospital-line' },
    { number: '24/7', label: 'Emergency Care', icon: 'ri-time-line' }
  ];

  const services = [
    { 
      icon: 'ri-heart-pulse-line', 
      title: 'Cardiology', 
      desc: 'Advanced heart and cardiovascular treatments with state-of-the-art technology',
      features: ['ECG & Echo', 'Cardiac Surgery', 'Heart Monitoring']
    },
    { 
      icon: 'ri-brain-line', 
      title: 'Neurology', 
      desc: 'Comprehensive neurological care for brain and nervous system disorders',
      features: ['Brain Imaging', 'Stroke Care', 'Memory Clinic']
    },
    { 
      icon: 'ri-parent-line', 
      title: 'Pediatrics', 
      desc: 'Specialized medical care designed specifically for infants and children',
      features: ['Vaccinations', 'Growth Monitoring', 'Child Psychology']
    },
    { 
      icon: 'ri-surgical-mask-line', 
      title: 'Surgery', 
      desc: 'Advanced surgical procedures with minimally invasive techniques',
      features: ['Robotic Surgery', 'Laparoscopy', 'Day Surgery']
    },
    { 
      icon: 'ri-lungs-line', 
      title: 'Pulmonology', 
      desc: 'Respiratory and lung health specialists with comprehensive care',
      features: ['Lung Function Tests', 'Sleep Studies', 'Asthma Care']
    },
    { 
      icon: 'ri-bone-line', 
      title: 'Orthopedics', 
      desc: 'Musculoskeletal system treatment and sports injury rehabilitation',
      features: ['Joint Replacement', 'Sports Medicine', 'Physiotherapy']
    }
  ];

  useEffect(() => {
    setIsMounted(true);
  }, []);

  useEffect(() => {
    if (!isMounted) return;

    const testimonialInterval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 4000);

    return () => clearInterval(testimonialInterval);
  }, [isMounted, testimonials.length]);

  useEffect(() => {
    if (!isMounted) return;

    const statInterval = setInterval(() => {
      setCurrentStat((prev) => (prev + 1) % stats.length);
    }, 2000);

    return () => clearInterval(statInterval);
  }, [isMounted, stats.length]);

  if (!isMounted) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-sky-100">
      <Header />
      
      {/* Enhanced Hero Section with Floating Elements */}
      <section className="relative bg-gradient-to-br from-sky-400 via-sky-500 to-sky-600 min-h-screen flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-sky-500/80 to-sky-600/60"></div>
        
        {/* Floating Animation Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-20 h-20 bg-white/10 rounded-full animate-bounce" style={{animationDelay: '0s', animationDuration: '3s'}}></div>
          <div className="absolute top-40 right-20 w-16 h-16 bg-white/10 rounded-full animate-bounce" style={{animationDelay: '1s', animationDuration: '4s'}}></div>
          <div className="absolute bottom-32 left-20 w-12 h-12 bg-white/10 rounded-full animate-bounce" style={{animationDelay: '2s', animationDuration: '5s'}}></div>
          <div className="absolute bottom-20 right-32 w-24 h-24 bg-white/10 rounded-full animate-bounce" style={{animationDelay: '1.5s', animationDuration: '3.5s'}}></div>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="w-full animate-fade-in-up">
              <div className="inline-flex items-center bg-white/20 backdrop-blur-sm rounded-full px-6 py-2 mb-6">
                <i className="ri-award-line text-white mr-2"></i>
                <span className="text-white font-medium">Award-winning Healthcare Excellence</span>
              </div>
              <h1 className="text-5xl lg:text-7xl font-bold text-white leading-tight mb-6">
                Your Health, Our <span className="text-sky-100 relative">
                  Priority
                  <div className="absolute -bottom-2 left-0 w-full h-1 bg-white/50 rounded-full"></div>
                </span>
              </h1>
              <p className="text-xl text-sky-100 mb-8 leading-relaxed">
                Experience world-class healthcare with our team of expert doctors and state-of-the-art facilities. Book your appointment today for personalized medical care that puts you first.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <Link href="/appointment" className="group bg-white text-sky-600 px-8 py-4 rounded-full text-lg font-semibold hover:bg-sky-50 transition-all duration-300 cursor-pointer text-center whitespace-nowrap shadow-lg transform hover:scale-105 hover:shadow-xl">
                  <span className="mr-2">Book Appointment</span>
                  <i className="ri-arrow-right-line group-hover:translate-x-1 transition-transform"></i>
                </Link>
                <Link href="/doctors" className="group border-2 border-white text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-white hover:text-sky-600 transition-all duration-300 cursor-pointer text-center whitespace-nowrap transform hover:scale-105">
                  <span className="mr-2">Find Doctors</span>
                  <i className="ri-user-line group-hover:rotate-12 transition-transform"></i>
                </Link>
              </div>
              
              {/* Quick Stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {stats.map((stat, index) => (
                  <div key={index} className="text-center bg-white/10 backdrop-blur-sm rounded-lg p-3">
                    <div className="text-2xl font-bold text-white">{stat.number}</div>
                    <div className="text-sky-100 text-sm">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="hidden lg:block relative">
              <div className="relative">
                <img 
                  src="https://readdy.ai/api/search-image?query=Modern%20hospital%20interior%20with%20clean%20white%20and%20light%20blue%20design%2C%20professional%20medical%20environment%20with%20soft%20natural%20lighting%2C%20minimalist%20healthcare%20facility%20background%20with%20calming%20atmosphere%20and%20medical%20equipment%20in%20distance%2C%20spacious%20lobby%20with%20comfortable%20seating&width=600&height=500&seq=hero1&orientation=landscape"
                  alt="Modern Hospital"
                  className="w-full h-auto rounded-2xl shadow-2xl transform hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute -top-4 -right-4 bg-white rounded-full p-4 shadow-lg animate-pulse">
                  <i className="ri-heart-pulse-line text-sky-600 text-2xl"></i>
                </div>
                <div className="absolute -bottom-4 -left-4 bg-white rounded-full p-4 shadow-lg animate-pulse" style={{animationDelay: '1s'}}>
                  <i className="ri-shield-check-line text-green-600 text-2xl"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Services Overview with Interactive Cards */}
      <section className="py-20 bg-gradient-to-r from-sky-50 to-blue-100 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-16">
            <div className="inline-flex items-center bg-sky-200 rounded-full px-6 py-2 mb-4">
              <i className="ri-service-line text-sky-600 mr-2"></i>
              <span className="text-sky-700 font-medium">Our Expertise</span>
            </div>
            <h2 className="text-5xl font-bold text-sky-800 mb-6">Comprehensive Medical Services</h2>
            <p className="text-xl text-sky-700 max-w-3xl mx-auto">
              From routine check-ups to complex procedures, we deliver healthcare excellence across all specialties
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="group bg-white p-8 rounded-2xl hover:shadow-2xl transition-all duration-500 hover:scale-105 border border-sky-200 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-sky-100 to-transparent rounded-full -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500"></div>
                <div className="relative z-10">
                  <div className="w-16 h-16 bg-gradient-to-br from-sky-400 to-sky-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg group-hover:rotate-12 transition-transform duration-300">
                    <i className={`${service.icon} text-white text-2xl`}></i>
                  </div>
                  <h3 className="text-2xl font-bold text-sky-800 mb-3">{service.title}</h3>
                  <p className="text-sky-600 mb-4 leading-relaxed">{service.desc}</p>
                  <ul className="space-y-2">
                    {service.features.map((feature, fIndex) => (
                      <li key={fIndex} className="flex items-center text-sky-700">
                        <i className="ri-check-line text-green-500 mr-2"></i>
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="mt-6 pt-4 border-t border-sky-100">
                    <Link href="/services" className="text-sky-600 font-medium hover:text-sky-800 transition-colors group-hover:translate-x-2 transform duration-300 inline-flex items-center">
                      Learn More 
                      <i className="ri-arrow-right-line ml-1 group-hover:translate-x-1 transition-transform"></i>
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Enhanced Doctors Section with Hover Effects */}
      <section className="py-20 bg-gradient-to-br from-sky-100 via-sky-200 to-blue-200">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <div className="inline-flex items-center bg-sky-300 rounded-full px-6 py-2 mb-4">
              <i className="ri-team-line text-sky-700 mr-2"></i>
              <span className="text-sky-800 font-medium">Medical Team</span>
            </div>
            <h2 className="text-5xl font-bold text-sky-800 mb-6">Meet Our Expert Doctors</h2>
            <p className="text-xl text-sky-700 max-w-2xl mx-auto">
              Board-certified physicians dedicated to providing exceptional care with years of specialized experience
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {doctors.map((doctor, index) => (
              <div key={doctor.id} className="group bg-white rounded-2xl shadow-xl overflow-hidden hover:shadow-2xl transition-all duration-500 hover:scale-105 border-2 border-sky-300 relative">
                <div className="aspect-square overflow-hidden relative">
                  <img 
                    src={doctor.image} 
                    alt={doctor.name}
                    className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <i className="ri-stethoscope-line text-sky-600"></i>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-sky-800 mb-1">{doctor.name}</h3>
                  <p className="text-sky-600 font-medium mb-2 bg-sky-100 px-3 py-1 rounded-full text-sm inline-block">{doctor.specialty}</p>
                  <p className="text-sky-600 text-sm mb-3 flex items-center">
                    <i className="ri-time-line text-sky-400 mr-1"></i>
                    {doctor.experience} experience
                  </p>
                  <div className="flex items-center justify-between mb-4 bg-sky-50 p-3 rounded-lg">
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <i key={i} className="ri-star-fill text-sm"></i>
                      ))}
                    </div>
                    <span className="text-sky-700 text-sm font-bold">{doctor.rating}</span>
                  </div>
                  <Link href="/appointment" className="group/btn w-full bg-gradient-to-r from-sky-500 to-sky-600 text-white py-3 rounded-full text-center hover:from-sky-600 hover:to-sky-700 transition-all duration-300 cursor-pointer block whitespace-nowrap font-semibold shadow-lg hover:shadow-xl transform hover:scale-105">
                    <span className="mr-1">Book Appointment</span>
                    <i className="ri-calendar-line group-hover/btn:rotate-12 transition-transform"></i>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Enhanced Quick Appointment Form */}
      <section className="py-20 bg-gradient-to-r from-sky-400 via-sky-500 to-sky-600 relative overflow-hidden">
        <div className="absolute inset-0 bg-medical-pattern opacity-10"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-flex items-center bg-white/20 backdrop-blur-sm rounded-full px-6 py-2 mb-4">
                <i className="ri-calendar-check-line text-white mr-2"></i>
                <span className="text-white font-medium">Quick Booking</span>
              </div>
              <h2 className="text-5xl font-bold text-white mb-4">Schedule Your Visit</h2>
              <p className="text-xl text-sky-100">
                Book your appointment in just a few clicks - available 24/7 online
              </p>
            </div>
            
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-8 shadow-2xl border border-white/20">
              <form className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="group">
                  <label className="block text-sky-800 font-semibold mb-3 flex items-center">
                    <i className="ri-user-line text-sky-600 mr-2"></i>
                    Select Doctor
                  </label>
                  <div className="relative">
                    <button type="button" className="w-full bg-sky-50 border-2 border-sky-300 rounded-xl px-4 py-4 text-left focus:outline-none focus:ring-2 focus:ring-sky-500 pr-8 cursor-pointer text-sky-700 hover:bg-sky-100 transition-colors group-hover:border-sky-400">
                      {selectedDoctor || 'Choose doctor...'}
                    </button>
                    <div className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 flex items-center justify-center">
                      <i className="ri-arrow-down-s-line text-sky-400 group-hover:text-sky-600 transition-colors"></i>
                    </div>
                  </div>
                </div>
                
                <div className="group">
                  <label className="block text-sky-800 font-semibold mb-3 flex items-center">
                    <i className="ri-calendar-line text-sky-600 mr-2"></i>
                    Select Date
                  </label>
                  <input 
                    type="date" 
                    className="w-full bg-sky-50 border-2 border-sky-300 rounded-xl px-4 py-4 focus:outline-none focus:ring-2 focus:ring-sky-500 text-sky-700 hover:bg-sky-100 transition-colors group-hover:border-sky-400"
                    value={appointmentDate}
                    onChange={(e) => setAppointmentDate(e.target.value)}
                  />
                </div>
                
                <div className="group">
                  <label className="block text-sky-800 font-semibold mb-3 flex items-center">
                    <i className="ri-time-line text-sky-600 mr-2"></i>
                    Select Time
                  </label>
                  <div className="relative">
                    <button type="button" className="w-full bg-sky-50 border-2 border-sky-300 rounded-xl px-4 py-4 text-left focus:outline-none focus:ring-2 focus:ring-sky-500 pr-8 cursor-pointer text-sky-700 hover:bg-sky-100 transition-colors group-hover:border-sky-400">
                      {appointmentTime || 'Choose time...'}
                    </button>
                    <div className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 flex items-center justify-center">
                      <i className="ri-arrow-down-s-line text-sky-400 group-hover:text-sky-600 transition-colors"></i>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-end">
                  <Link href="/appointment" className="w-full bg-gradient-to-r from-sky-500 to-sky-600 text-white py-4 rounded-xl text-center font-bold hover:from-sky-600 hover:to-sky-700 transition-all duration-300 cursor-pointer whitespace-nowrap shadow-lg hover:shadow-xl transform hover:scale-105 flex items-center justify-center">
                    <i className="ri-arrow-right-circle-line mr-2 text-xl"></i>
                    Book Now
                  </Link>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Stats Section */}
      <section className="py-20 bg-gradient-to-r from-sky-50 to-blue-100">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-sky-800 mb-4">Our Impact in Numbers</h2>
            <p className="text-xl text-sky-700">Trusted by thousands of patients across the region</p>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className={`text-center p-8 rounded-2xl transition-all duration-500 ${index === currentStat ? 'bg-gradient-to-br from-sky-500 to-sky-600 text-white scale-110 shadow-2xl' : 'bg-white text-sky-800 hover:shadow-lg'}`}>
                <div className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center ${index === currentStat ? 'bg-white/20' : 'bg-sky-100'}`}>
                  <i className={`${stat.icon} text-2xl ${index === currentStat ? 'text-white' : 'text-sky-600'}`}></i>
                </div>
                <div className="text-4xl font-bold mb-2">{stat.number}</div>
                <div className={`text-lg ${index === currentStat ? 'text-sky-100' : 'text-sky-600'}`}>{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Enhanced Testimonials Carousel */}
      <section className="py-20 bg-gradient-to-br from-sky-100 via-blue-100 to-sky-200">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <div className="inline-flex items-center bg-sky-200 rounded-full px-6 py-2 mb-4">
              <i className="ri-chat-quote-line text-sky-700 mr-2"></i>
              <span className="text-sky-800 font-medium">Patient Stories</span>
            </div>
            <h2 className="text-5xl font-bold text-sky-800 mb-6">What Our Patients Say</h2>
            <p className="text-xl text-sky-700">
              Real experiences from our valued patients and their families
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto relative">
            <div className="bg-white rounded-3xl p-12 shadow-2xl border-4 border-sky-200 relative overflow-hidden">
              <div className="absolute top-6 left-6 text-6xl text-sky-200 font-serif">"</div>
              <div className="absolute bottom-6 right-6 text-6xl text-sky-200 font-serif rotate-180">"</div>
              
              <div className="text-center relative z-10">
                <div className="flex justify-center text-yellow-400 mb-6">
                  {[...Array(testimonials[currentTestimonial].rating)].map((_, i) => (
                    <i key={i} className="ri-star-fill text-2xl mx-1"></i>
                  ))}
                </div>
                <p className="text-2xl text-sky-700 mb-8 leading-relaxed font-medium">
                  {testimonials[currentTestimonial].text}
                </p>
                <div className="flex items-center justify-center">
                  <img 
                    src={testimonials[currentTestimonial].image} 
                    alt={testimonials[currentTestimonial].name}
                    className="w-16 h-16 rounded-full object-cover object-top mr-4 border-4 border-sky-300 shadow-lg"
                  />
                  <div className="text-left">
                    <h4 className="text-xl font-bold text-sky-800">{testimonials[currentTestimonial].name}</h4>
                    <p className="text-sky-600">{testimonials[currentTestimonial].role}</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex justify-center mt-8 space-x-3">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentTestimonial(index)}
                  className={`w-4 h-4 rounded-full transition-all duration-300 cursor-pointer ${
                    index === currentTestimonial ? 'bg-sky-600 scale-125' : 'bg-sky-300 hover:bg-sky-400'
                  }`}
                ></button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Contact Section */}
      <section className="py-20 bg-gradient-to-r from-sky-50 to-blue-100">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <div className="inline-flex items-center bg-sky-200 rounded-full px-6 py-2 mb-6">
                <i className="ri-customer-service-2-line text-sky-700 mr-2"></i>
                <span className="text-sky-800 font-medium">Contact Us</span>
              </div>
              <h2 className="text-5xl font-bold text-sky-800 mb-6">Get In Touch</h2>
              <p className="text-xl text-sky-700 mb-8">
                Have questions about our services? Our team is here to help you 24/7 with any healthcare inquiries.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-4 group">
                  <div className="w-14 h-14 bg-gradient-to-br from-sky-400 to-sky-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                    <i className="ri-map-pin-line text-white text-xl"></i>
                  </div>
                  <div>
                    <h3 className="font-bold text-sky-800 mb-2 text-lg">Visit Our Hospital</h3>
                    <p className="text-sky-600">123 Healthcare Avenue<br/>Medical District, City 12345</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4 group">
                  <div className="w-14 h-14 bg-gradient-to-br from-sky-400 to-sky-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                    <i className="ri-phone-line text-white text-xl"></i>
                  </div>
                  <div>
                    <h3 className="font-bold text-sky-800 mb-2 text-lg">Call Us</h3>
                    <p className="text-sky-600">Emergency: +1 (555) 911-HELP<br/>Appointments: +1 (555) 123-4567</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4 group">
                  <div className="w-14 h-14 bg-gradient-to-br from-sky-400 to-sky-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                    <i className="ri-time-line text-white text-xl"></i>
                  </div>
                  <div>
                    <h3 className="font-bold text-sky-800 mb-2 text-lg">Operating Hours</h3>
                    <p className="text-sky-600">Mon-Fri: 8AM-8PM<br/>Sat-Sun: 9AM-5PM<br/>Emergency: 24/7</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 shadow-2xl border-2 border-sky-200">
              <h3 className="text-2xl font-bold text-sky-800 mb-6 text-center">Send us a Message</h3>
              <form className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <input 
                    type="text" 
                    placeholder="First Name"
                    className="w-full bg-sky-50 border-2 border-sky-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500 text-sky-700 hover:bg-sky-100 transition-colors"
                  />
                  <input 
                    type="text" 
                    placeholder="Last Name"
                    className="w-full bg-sky-50 border-2 border-sky-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500 text-sky-700 hover:bg-sky-100 transition-colors"
                  />
                </div>
                <input 
                  type="email" 
                  placeholder="Email Address"
                  className="w-full bg-sky-50 border-2 border-sky-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500 text-sky-700 hover:bg-sky-100 transition-colors"
                />
                <input 
                  type="tel" 
                  placeholder="Phone Number"
                  className="w-full bg-sky-50 border-2 border-sky-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500 text-sky-700 hover:bg-sky-100 transition-colors"
                />
                <textarea 
                  placeholder="Your Message"
                  rows={4}
                  maxLength={500}
                  className="w-full bg-sky-50 border-2 border-sky-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500 resize-none text-sky-700 hover:bg-sky-100 transition-colors"
                ></textarea>
                <button 
                  type="submit"
                  className="w-full bg-gradient-to-r from-sky-500 to-sky-600 text-white py-4 rounded-xl font-bold hover:from-sky-600 hover:to-sky-700 transition-all duration-300 cursor-pointer whitespace-nowrap shadow-lg hover:shadow-xl transform hover:scale-105 flex items-center justify-center"
                >
                  <i className="ri-send-plane-line mr-2"></i>
                  Send Message
                </button>
              </form>
            </div>
          </div>
          
          <div className="mt-16 rounded-3xl overflow-hidden shadow-2xl border-4 border-sky-300">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3024.123456789!2d-74.006!3d40.7128!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDDCsDQyJzQ2LjEiTiA3NMKwMDAnMjEuNiJX!5e0!3m2!1sen!2sus!4v1234567890"
              width="100%"
              height="450"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}