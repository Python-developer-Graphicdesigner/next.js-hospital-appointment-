'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';
import { useState } from 'react';

export default function RegisterPage() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    dateOfBirth: '',
    gender: '',
    password: '',
    confirmPassword: '',
    agreeTerms: false
  });

  const [showAlert, setShowAlert] = useState({ show: false, type: '', message: '' });

  const handleInputChange = (e: any) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({ 
      ...prev, 
      [name]: type === 'checkbox' ? checked : value 
    }));
  };

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    
    if (formData.password !== formData.confirmPassword) {
      setShowAlert({ 
        show: true, 
        type: 'error', 
        message: 'Passwords do not match. Please try again.' 
      });
      return;
    }

    if (!formData.agreeTerms) {
      setShowAlert({ 
        show: true, 
        type: 'error', 
        message: 'Please agree to the terms and conditions.' 
      });
      return;
    }
    
    const registerData = new URLSearchParams();
    Object.entries(formData).forEach(([key, value]) => {
      registerData.append(key, value.toString());
    });

    try {
      const response = await fetch('/api/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: registerData
      });

      if (response.ok) {
        setShowAlert({ 
          show: true, 
          type: 'success', 
          message: 'Registration successful! Please check your email for verification.' 
        });
        setFormData({
          firstName: '', lastName: '', email: '', phone: '', dateOfBirth: '', gender: '',
          password: '', confirmPassword: '', agreeTerms: false
        });
      } else {
        throw new Error('Registration failed');
      }
    } catch (error) {
      setShowAlert({ 
        show: true, 
        type: 'error', 
        message: 'Registration failed. Please try again.' 
      });
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <div className="bg-sky-50 py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-gray-800 mb-2">Create Your Account</h1>
              <p className="text-gray-600">Join MediCare to access personalized healthcare services</p>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-8">
              <form id="register-form" onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">First Name *</label>
                    <input 
                      type="text" 
                      name="firstName"
                      value={formData.firstName}
                      onChange={handleInputChange}
                      className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Last Name *</label>
                    <input 
                      type="text" 
                      name="lastName"
                      value={formData.lastName}
                      onChange={handleInputChange}
                      className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                      required
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Email Address *</label>
                    <input 
                      type="email" 
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Phone Number *</label>
                    <input 
                      type="tel" 
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                      required
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Date of Birth *</label>
                    <input 
                      type="date" 
                      name="dateOfBirth"
                      value={formData.dateOfBirth}
                      onChange={handleInputChange}
                      className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Gender *</label>
                    <div className="relative">
                      <select 
                        name="gender"
                        value={formData.gender}
                        onChange={handleInputChange}
                        className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500 pr-8"
                        required
                      >
                        <option value="">Select Gender</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Password *</label>
                    <input 
                      type="password" 
                      name="password"
                      value={formData.password}
                      onChange={handleInputChange}
                      className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Confirm Password *</label>
                    <input 
                      type="password" 
                      name="confirmPassword"
                      value={formData.confirmPassword}
                      onChange={handleInputChange}
                      className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                      required
                    />
                  </div>
                </div>
                
                <div className="flex items-start">
                  <input 
                    type="checkbox" 
                    name="agreeTerms"
                    checked={formData.agreeTerms}
                    onChange={handleInputChange}
                    className="rounded border-gray-300 text-sky-600 focus:ring-sky-500 mt-1"
                    required
                  />
                  <span className="ml-3 text-sm text-gray-600">
                    I agree to the 
                    <Link href="/terms" className="text-sky-600 hover:text-sky-700 mx-1 cursor-pointer">Terms of Service</Link>
                    and 
                    <Link href="/privacy" className="text-sky-600 hover:text-sky-700 mx-1 cursor-pointer">Privacy Policy</Link>
                  </span>
                </div>
                
                <button 
                  type="submit"
                  className="w-full bg-sky-500 text-white py-3 rounded-lg font-semibold hover:bg-sky-600 transition-colors cursor-pointer whitespace-nowrap"
                >
                  Create Account
                </button>
              </form>
              
              <div className="mt-6 text-center">
                <p className="text-gray-600">
                  Already have an account? 
                  <Link href="/signin" className="text-sky-600 hover:text-sky-700 font-medium ml-1 cursor-pointer">
                    Sign in here
                  </Link>
                </p>
              </div>

              <div className="mt-8 pt-6 border-t border-gray-200">
                <div className="text-center text-sm text-gray-500 mb-4">Or register with</div>
                <div className="grid grid-cols-2 gap-4">
                  <button className="flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
                    <i className="ri-google-fill text-red-500 mr-2"></i>
                    <span className="text-sm">Google</span>
                  </button>
                  <button className="flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
                    <i className="ri-facebook-fill text-blue-600 mr-2"></i>
                    <span className="text-sm">Facebook</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Alert Modal */}
      {showAlert.show && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 max-w-md mx-4">
            <div className="flex items-center mb-4">
              <div className={`w-12 h-12 rounded-full flex items-center justify-center mr-4 ${
                showAlert.type === 'success' ? 'bg-green-100' : 'bg-red-100'
              }`}>
                <i className={`${showAlert.type === 'success' ? 'ri-check-line text-green-600' : 'ri-error-warning-line text-red-600'} text-2xl`}></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-800">
                {showAlert.type === 'success' ? 'Success!' : 'Error'}
              </h3>
            </div>
            <p className="text-gray-600 mb-6">{showAlert.message}</p>
            <button 
              onClick={() => setShowAlert({ show: false, type: '', message: '' })}
              className="w-full bg-sky-500 text-white py-3 rounded-lg font-semibold hover:bg-sky-600 transition-colors cursor-pointer whitespace-nowrap"
            >
              Close
            </button>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}