'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';
import { useState } from 'react';

export default function SignInPage() {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    rememberMe: false
  });

  const [showAlert, setShowAlert] = useState({ show: false, type: '', message: '' });

  const handleInputChange = (e: any) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({ 
      ...prev, 
      [name]: type === 'checkbox' ? checked : value 
    }));
  };

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    
    const signinData = new URLSearchParams();
    Object.entries(formData).forEach(([key, value]) => {
      signinData.append(key, value.toString());
    });

    try {
      const response = await fetch('/api/signin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: signinData
      });

      if (response.ok) {
        setShowAlert({ 
          show: true, 
          type: 'success', 
          message: 'Sign in successful! Redirecting to dashboard...' 
        });
        setTimeout(() => {
          window.location.href = '/dashboard';
        }, 2000);
      } else {
        throw new Error('Sign in failed');
      }
    } catch (error) {
      setShowAlert({ 
        show: true, 
        type: 'error', 
        message: 'Invalid email or password. Please try again.' 
      });
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <div className="bg-sky-50 py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-md mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-gray-800 mb-2">Welcome Back</h1>
              <p className="text-gray-600">Sign in to access your patient dashboard</p>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-8">
              <form id="signin-form" onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-gray-700 font-medium mb-2">Email Address</label>
                  <input 
                    type="email" 
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                    placeholder="Enter your email"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-gray-700 font-medium mb-2">Password</label>
                  <input 
                    type="password" 
                    name="password"
                    value={formData.password}
                    onChange={handleInputChange}
                    className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500"
                    placeholder="Enter your password"
                    required
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <label className="flex items-center">
                    <input 
                      type="checkbox" 
                      name="rememberMe"
                      checked={formData.rememberMe}
                      onChange={handleInputChange}
                      className="rounded border-gray-300 text-sky-600 focus:ring-sky-500"
                    />
                    <span className="ml-2 text-sm text-gray-600">Remember me</span>
                  </label>
                  
                  <Link href="/forgot-password" className="text-sm text-sky-600 hover:text-sky-700 cursor-pointer">
                    Forgot password?
                  </Link>
                </div>
                
                <button 
                  type="submit"
                  className="w-full bg-sky-500 text-white py-3 rounded-lg font-semibold hover:bg-sky-600 transition-colors cursor-pointer whitespace-nowrap"
                >
                  Sign In
                </button>
              </form>
              
              <div className="mt-6 text-center">
                <p className="text-gray-600">
                  Don't have an account? 
                  <Link href="/register" className="text-sky-600 hover:text-sky-700 font-medium ml-1 cursor-pointer">
                    Register here
                  </Link>
                </p>
              </div>

              <div className="mt-8 pt-6 border-t border-gray-200">
                <div className="text-center text-sm text-gray-500 mb-4">Or sign in with</div>
                <div className="grid grid-cols-2 gap-4">
                  <button className="flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
                    <i className="ri-google-fill text-red-500 mr-2"></i>
                    <span className="text-sm">Google</span>
                  </button>
                  <button className="flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
                    <i className="ri-facebook-fill text-blue-600 mr-2"></i>
                    <span className="text-sm">Facebook</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="mt-8 bg-sky-100 rounded-lg p-4">
              <h3 className="font-semibold text-gray-800 mb-2">Demo Credentials</h3>
              <p className="text-sm text-gray-600 mb-1">Email: patient@medicare.com</p>
              <p className="text-sm text-gray-600">Password: demo123</p>
            </div>
          </div>
        </div>
      </div>

      {/* Alert Modal */}
      {showAlert.show && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 max-w-md mx-4">
            <div className="flex items-center mb-4">
              <div className={`w-12 h-12 rounded-full flex items-center justify-center mr-4 ${
                showAlert.type === 'success' ? 'bg-green-100' : 'bg-red-100'
              }`}>
                <i className={`${showAlert.type === 'success' ? 'ri-check-line text-green-600' : 'ri-error-warning-line text-red-600'} text-2xl`}></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-800">
                {showAlert.type === 'success' ? 'Success!' : 'Error'}
              </h3>
            </div>
            <p className="text-gray-600 mb-6">{showAlert.message}</p>
            <button 
              onClick={() => setShowAlert({ show: false, type: '', message: '' })}
              className="w-full bg-sky-500 text-white py-3 rounded-lg font-semibold hover:bg-sky-600 transition-colors cursor-pointer whitespace-nowrap"
            >
              Close
            </button>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}