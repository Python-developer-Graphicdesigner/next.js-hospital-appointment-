'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-sky-50 border-t border-sky-100">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-sky-500 rounded-full flex items-center justify-center">
                <i className="ri-hospital-line text-white text-lg"></i>
              </div>
              <span className="text-xl font-bold text-sky-600" style={{fontFamily: "Pacifico, serif"}}>
                MediCare
              </span>
            </div>
            <p className="text-gray-600 text-sm">
              Providing quality healthcare services with compassion and excellence. Your health is our priority.
            </p>
            <div className="flex space-x-4">
              <div className="w-8 h-8 flex items-center justify-center">
                <i className="ri-facebook-fill text-sky-500 text-xl cursor-pointer hover:text-sky-600"></i>
              </div>
              <div className="w-8 h-8 flex items-center justify-center">
                <i className="ri-twitter-fill text-sky-500 text-xl cursor-pointer hover:text-sky-600"></i>
              </div>
              <div className="w-8 h-8 flex items-center justify-center">
                <i className="ri-instagram-fill text-sky-500 text-xl cursor-pointer hover:text-sky-600"></i>
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-gray-800 mb-4">Quick Links</h3>
            <div className="space-y-2">
              <Link href="/doctors" className="block text-gray-600 hover:text-sky-600 text-sm cursor-pointer">
                Find Doctors
              </Link>
              <Link href="/appointment" className="block text-gray-600 hover:text-sky-600 text-sm cursor-pointer">
                Book Appointment
              </Link>
              <Link href="/services" className="block text-gray-600 hover:text-sky-600 text-sm cursor-pointer">
                Our Services
              </Link>
              <Link href="/dashboard" className="block text-gray-600 hover:text-sky-600 text-sm cursor-pointer">
                Patient Portal
              </Link>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-gray-800 mb-4">Services</h3>
            <div className="space-y-2">
              <p className="text-gray-600 text-sm">Emergency Care</p>
              <p className="text-gray-600 text-sm">General Medicine</p>
              <p className="text-gray-600 text-sm">Surgery</p>
              <p className="text-gray-600 text-sm">Pediatrics</p>
              <p className="text-gray-600 text-sm">Cardiology</p>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-gray-800 mb-4">Contact Info</h3>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <div className="w-5 h-5 flex items-center justify-center mt-0.5">
                  <i className="ri-map-pin-line text-sky-500"></i>
                </div>
                <p className="text-gray-600 text-sm">123 Healthcare Ave, Medical District, City 12345</p>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-5 h-5 flex items-center justify-center">
                  <i className="ri-phone-line text-sky-500"></i>
                </div>
                <p className="text-gray-600 text-sm">+1 (555) 123-4567</p>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-5 h-5 flex items-center justify-center">
                  <i className="ri-mail-line text-sky-500"></i>
                </div>
                <p className="text-gray-600 text-sm">info@medicare.com</p>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-sky-200 mt-8 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-600 text-sm">
              © 2024 MediCare Hospital. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link href="/privacy" className="text-gray-600 hover:text-sky-600 text-sm cursor-pointer">
                Privacy Policy
              </Link>
              <Link href="/terms" className="text-gray-600 hover:text-sky-600 text-sm cursor-pointer">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}